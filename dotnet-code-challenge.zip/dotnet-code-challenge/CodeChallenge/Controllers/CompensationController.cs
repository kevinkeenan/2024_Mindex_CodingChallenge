﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CodeChallenge.Services;
using CodeChallenge.Models;

namespace CodeChallenge.Controllers
{
    [ApiController]
    [Route("api/compensation")]
    public class CompensationController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly ICompensationService _compensationService;
        private readonly IEmployeeService _employeeService;

        public CompensationController(ILogger<CompensationController> logger, ICompensationService compensationService, IEmployeeService employeeService)
        {
            _logger = logger;
            _compensationService = compensationService;
            _employeeService = employeeService;
        }

        [HttpPost]
        public IActionResult CreateCompensation([FromBody] Compensation compensation)
        {
            _logger.LogDebug($"Received compensation create request for employee '{compensation.Employee.FirstName}' {compensation.Employee.LastName}");

            var employee = _employeeService.GetById(compensation.Employee.EmployeeId);
            if(employee == null) 
            {
                _logger.LogDebug($"There is no such employee id {compensation.Employee.EmployeeId}. must provide valid id");
                return BadRequest();

            }
            compensation.Employee = employee;
            _compensationService.Create(compensation);

            return CreatedAtRoute("getCompensationByEmployeeId", new { id = compensation }, compensation);
        }

        [HttpGet("{id}", Name = "getCompensationByEmployeeId")]
        public IActionResult GetCompensationByEmployeeId(string id)
        {
            _logger.LogDebug($"Received compensation get request for employee id '{id}'");

            var employee = _employeeService.GetById(id);
            var compensation = _compensationService.GetById(id);
            if (compensation == null)
                return NotFound();

            compensation.Employee = employee;



            return Ok(compensation);
        }

        [HttpPut("{id}")]
        public IActionResult ReplaceCompensation(string id, [FromBody] Compensation newCompensation)
        {
            _logger.LogDebug($"Recieved compensation update request for employee id '{id}'");

            var employee = _employeeService.GetById(id);

            var existingCompensation = _compensationService.GetById(id);
            if (existingCompensation == null)
                return NotFound();
            existingCompensation.Employee = employee;
            newCompensation.Employee = employee;

            _compensationService.Replace(existingCompensation, newCompensation);

            return Ok(newCompensation);
        }
    }
}
