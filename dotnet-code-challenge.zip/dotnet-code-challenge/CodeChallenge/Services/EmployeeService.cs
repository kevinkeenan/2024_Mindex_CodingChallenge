﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CodeChallenge.Models;
using Microsoft.Extensions.Logging;
using CodeChallenge.Repositories;

namespace CodeChallenge.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepository _employeeRepository;
        private readonly ILogger<EmployeeService> _logger;

        public EmployeeService(ILogger<EmployeeService> logger, IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
            _logger = logger;
        }

        /// <summary>
        /// Creates a new employee. also checks first that the employee does not already exist
        /// checks that the employee cannot manage themself
        /// </summary>
        /// <param name="employee"></param>
        /// <returns></returns>
        public Employee Create(Employee employee)
        {
            if(employee != null)
            {
                var existingEmployee = GetById(employee.EmployeeId);
                if (existingEmployee != null)
                {
                    _logger.LogDebug("Employee already exists");
                    return null;
                }
                if(employee.DirectReports != null)
                {
                    foreach (var directReport in employee.DirectReports)
                    {
                        if (employee.EmployeeId == directReport.EmployeeId)
                        {
                            _logger.LogDebug("Employee cannot report to themself");
                            return null;
                        }
                    }
                }

                _employeeRepository.Add(employee);
                _employeeRepository.SaveAsync().Wait();
            }

            return employee;
        }

        public Employee GetById(string id)
        {
            if(!String.IsNullOrEmpty(id))
            {
                return _employeeRepository.GetById(id);
            }

            return null;
        }


        /// <summary>
        /// this is weird and probalby buggy, refactor if i have time to not take in 2 arguments
        /// </summary>
        /// <param name="originalEmployee"></param>
        /// <param name="newEmployee"></param>
        /// <returns></returns>
        public Employee Replace(Employee originalEmployee, Employee newEmployee)
        {
            if(originalEmployee != null)
            {
                if (newEmployee != null)
                {
                    if(newEmployee.EmployeeId != originalEmployee.EmployeeId)
                    {
                        _logger.LogDebug("Employees are not the same, only allowed to edit same employee");
                        return null;
                    }
                    if(IsCircularReference(newEmployee))
                    {
                        _logger.LogDebug("Direct Reports cannot contain employees who are managers of current employees");
                        return null;
                    }
                    _employeeRepository.Remove(originalEmployee);//this removes before other checks...move it forward

                    // ensure the original has been removed, otherwise EF will complain another entity w/ same id already exists
                    _employeeRepository.SaveAsync().Wait();

                    _employeeRepository.Add(newEmployee);
                    // overwrite the new id with previous employee id
                    newEmployee.EmployeeId = originalEmployee.EmployeeId;
                }
                _employeeRepository.SaveAsync().Wait();
            }

            return newEmployee;
        }

        public ReportingStructure GetReportingStructureByEmployeedId(string id)
        {
            try
            {
                if (String.IsNullOrEmpty(id))
                {
                    //_logger.LogInformation($"EmployeeId cannot be null or empty.");
                    //TODO: Fix Logger DI
                    throw new ArgumentNullException();
                }
                return _employeeRepository.GetReportingStructureByEmployeedId(id);
            }
            catch (Exception ex)
            {
                //_logger.LogError($"Error getting reporting structure of employeed id {id}", ex);
                return null;
            }
        }

        /// <summary>
        /// Checks whether a circular reference exists within the employee hierarchy.
        /// </summary>
        /// <param name="newEmployee"></param>
        /// <returns></returns>
        public bool IsCircularReference(Employee newEmployee)
        {
            HashSet<string> visitedEmployees = new HashSet<string>();
            return IsCircularReferenceHelper(newEmployee, visitedEmployees);
        }

        /// <summary>
        /// Recursive helper method to perform depth-first search traversal and circular reference check.
        /// </summary>
        /// <param name="employee"></param>
        /// <param name="visitedEmployees"></param>
        /// <returns></returns>
        private bool IsCircularReferenceHelper(Employee employee, HashSet<string> visitedEmployees)
        {
            if (employee == null)
                return false;

            if (visitedEmployees.Contains(employee.EmployeeId))
                return true;

            visitedEmployees.Add(employee.EmployeeId);

            if (employee.DirectReports != null)
            {
                foreach (var directReport in employee.DirectReports)
                {
                    if (IsCircularReferenceHelper(directReport, visitedEmployees))
                        return true;
                }
            }

            visitedEmployees.Remove(employee.EmployeeId);
            return false;
        }
    }
}
