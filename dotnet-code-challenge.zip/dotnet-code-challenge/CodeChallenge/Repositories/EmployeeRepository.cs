﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CodeChallenge.Models;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using CodeChallenge.Data;

namespace CodeChallenge.Repositories
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly EmployeeContext _employeeContext;
        private readonly ILogger<IEmployeeRepository> _logger;

        public EmployeeRepository(ILogger<IEmployeeRepository> logger, EmployeeContext employeeContext)
        {
            _employeeContext = employeeContext;
            _logger = logger;
        }

        public Employee Add(Employee employee)
        {
            employee.EmployeeId = Guid.NewGuid().ToString();
            _employeeContext.Employees.Add(employee);
            return employee;
        }

        public Employee GetById(string id)
        {
            return _employeeContext.Employees.SingleOrDefault(e => e.EmployeeId == id);
        }

        public Task SaveAsync()
        {
            return _employeeContext.SaveChangesAsync();
        }

        public Employee Remove(Employee employee)
        {
            return _employeeContext.Remove(employee).Entity;
        }

        public ReportingStructure GetReportingStructureByEmployeedId(string id)
        {
            ReportingStructure reportingStructure = new ReportingStructure();
            var employee = GetById(id);
            reportingStructure.Employee = employee;
            reportingStructure.NumberOfReports = GetNumberOfUniqueReports(id, new HashSet<string>());

            //reportingStructure.NumberOfReports = GetNumberOfReports(id);
            return reportingStructure;
        }

        private int GetNumberOfUniqueReports(string id, HashSet<string> visitedEmployees)
        {
            var employee = GetById(id);
            if (employee == null)
            {
                return -1;
            }
            if (employee.DirectReports == null)
            {
                // Reached a leaf node
                return 0;
            }
            else
            {
                int totalDirectReports = 0;
                foreach (var directReport in employee.DirectReports)
                {
                    if (!visitedEmployees.Contains(directReport.EmployeeId))
                    {
                        visitedEmployees.Add(directReport.EmployeeId);
                        totalDirectReports++;
                        totalDirectReports += GetNumberOfUniqueReports(directReport.EmployeeId, visitedEmployees);
                    }
                }
                return totalDirectReports;
            }
        }
    }
}
