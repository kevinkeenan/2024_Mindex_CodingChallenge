﻿using System;

using CodeChallenge.Data;
using CodeChallenge.Repositories;
using CodeChallenge.Services;

using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace CodeChallenge.Config
{
    public class App
    {
        public WebApplication Configure(string[] args)
        {
            args ??= Array.Empty<string>();

            var builder = WebApplication.CreateBuilder(args);

            builder.UseEmployeeDB();

            var services = builder.Services;
            ConfigureServices(services);

            var app = builder.Build();

            var env = builder.Environment;
            if (env.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
                app.UseDeveloperExceptionPage();
                SeedEmployeeDB();
            }

            app.UseAuthorization();

            app.MapControllers();

            return app;
        }

        private void ConfigureServices(IServiceCollection services)
        {

            services.AddTransient<IEmployeeService, EmployeeService>();
            services.AddTransient<IEmployeeRepository, EmployeeRepository>();
            services.AddTransient<ICompensationService, CompensationService>();
            services.AddTransient<ICompensationRepository, CompensationRepository>();
            services.AddTransient<EmployeeDataSeeder>();

            services.AddControllers();
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen();
        }

        //private void SeedEmployeeDB()
        //{
        //    var seeder = new EmployeeDataSeeder(
        //        new EmployeeContext(
        //            new DbContextOptionsBuilder<EmployeeContext>().UseInMemoryDatabase("EmployeeDB").Options
        //    ));
        //    seeder.Seed().Wait();
        //    seeder.CompensationSeed().Wait();
        //}
        private void SeedEmployeeDB()
        {
            // Create an instance of EmployeeContext with an in-memory database
            var options = new DbContextOptionsBuilder<EmployeeContext>()
                          .UseInMemoryDatabase(databaseName: "EmployeeDB")
                          .Options;
            var context = new EmployeeContext(options);

            // Create an instance of EmployeeDataSeeder and pass the context to it
            var seeder = new EmployeeDataSeeder(context);

            // Seed employees
            seeder.Seed().Wait();

            // Seed compensations
            //seeder.CompensationSeed().Wait();

        }
    }
}
