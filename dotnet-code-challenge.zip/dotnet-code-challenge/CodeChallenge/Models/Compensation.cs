﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeChallenge.Models
{
    public class Compensation
    {
        public int Id { get; set; }
        [Required]
        public string EmployeeId { get; set; }

        [ForeignKey("EmployeeId")]
        public Employee Employee { get; set; }



        //Add some data validation so it cant be negative
        //Add some unit tests
        //Not all people should be able to see salary
        [Required]
        [Range(1,Double.MaxValue)]
        public double Salary { get; set; }
        
        //Add some data validation so it cant be in the past
        //Add some unit tests
        public DateTime EffectiveDate { get; set; }
    }
}
