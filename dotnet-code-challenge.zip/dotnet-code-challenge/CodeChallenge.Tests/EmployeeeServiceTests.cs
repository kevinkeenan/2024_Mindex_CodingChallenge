
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using CodeChallenge.Data;
using CodeChallenge.Models;
using CodeChallenge.Repositories;
using CodeChallenge.Services;
using CodeCodeChallenge.Tests.Integration.Extensions;
using CodeCodeChallenge.Tests.Integration.Helpers;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CodeCodeChallenge.Tests.Integration
{
    [TestClass]
    public class EmployeeeServiceTests
    {
        private static EmployeeContext _context;
        private static IEmployeeService _employeeService;
        private static IEmployeeRepository _employeeRepository;
        private static IServiceProvider _serviceProvider;
        private static ILogger<EmployeeService> _logger;


        [ClassInitialize]
        public static void InitializeClass(TestContext context)
        {
            var options = new DbContextOptionsBuilder<EmployeeContext>()
                .UseInMemoryDatabase(databaseName: "EmployeeDB")
                .Options;

            _context = new EmployeeContext(options);
            SeedTestData(_context);

            var services = new ServiceCollection();
            services.AddTransient<IEmployeeRepository, EmployeeRepository>();
            services.AddTransient<IEmployeeService, EmployeeService>();
            services.AddLogging(builder => builder.AddConsole());
            _serviceProvider = services.BuildServiceProvider();
            _logger = _serviceProvider.GetRequiredService<ILogger<EmployeeService>>();
            _employeeRepository = new EmployeeRepository(null, _context);
            _employeeService = new EmployeeService(_logger, _employeeRepository);
        }

        [ClassCleanup]
        public static void CleanUpTest()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
        }

        private async static void SeedTestData(EmployeeContext context)
        {
            // Your seeding logic here
            var dataSeeder = new EmployeeDataSeeder(context);
            await dataSeeder.Seed();
        }

        /// <summary>
        /// TODO: only works when run not with other update tests that mess with seeded data
        /// </summary>
        [TestMethod]
        public void GetReportingStructure_NonLeafNodeReturns_Correct()
        {
            // Arrange
            var employeeId = "03aa1462-ffa9-4978-901b-7c001562cf6f";
            var expectedCount = 2;

            // Act
            var reportingStructure = _employeeService.GetReportingStructureByEmployeedId(employeeId);

            // Assert
            Assert.AreEqual(expectedCount, reportingStructure.NumberOfReports);
        }

        [TestMethod]
        public void GetReportingStructure_LeafNodeReturns_Correct()
        {
            // Arrange
            var employeeId = "c0c2293d-16bd-4603-8e08-638a9d18b22c";
            var expectedCount = 0;

            // Act
            var reportingStructure = _employeeService.GetReportingStructureByEmployeedId(employeeId);

            // Assert
            Assert.AreEqual(expectedCount, reportingStructure.NumberOfReports);
        }

        /// <summary>
        /// TODO: only works when run not with other update tests that mess with seeded data
        /// </summary>
        [TestMethod]
        public void GetReportingStructure_WithDuplicateDirectReports_ShouldPass()
        {
            // Arrange
            var employeeId = "16a596ae-edd3-4847-99fe-c4518e82c86f";
            var expectedCount = 4;//added george harrison to seeded direct rpoerts of john lenon

            // Act
            var reportingStructure = _employeeService.GetReportingStructureByEmployeedId(employeeId);

            // Assert
            Assert.AreEqual(expectedCount, reportingStructure.NumberOfReports);
        }


        [TestMethod]
        [DataRow(null)]
        [DataRow("")]
        public void GetReportingStructure_NullEmployeeId_ShouldError(string employeeId)
        {
            //Act 
            var reportingStructure = _employeeService.GetReportingStructureByEmployeedId(employeeId);

            //Assert
            Assert.AreEqual(null, reportingStructure);
        }

        [TestMethod]
        [DataRow("invalid-id")]
        [DataRow("asdfasdfadsf")]
        public void GetReportingStructure_InvalidEmployeeId_ShouldError(string employeeId)
        {
            //Act 
            var reportingStructure = _employeeService.GetReportingStructureByEmployeedId(employeeId);

            //Assert
            //TODO: change this to be not dumb
            Assert.AreEqual(-1, reportingStructure.NumberOfReports);
        }

        /// <summary>
        /// This is one method of preventing a circular reference. We dont want to be able to create any duplicate employees in general
        /// But for completion sake, we want to make sure we block the case where we prevent a lower level employee from 
        /// being hired or created a bove the CEO. IE. Paul Mccartney -> John lennon -> Paul Mccartney 
        /// </summary>
        [TestMethod]
        public void CreateEmployee_EmployeeAlreadyExists_ShouldFail()
        {
            // Arrange
            var johnLennonEmployeeId = "16a596ae-edd3-4847-99fe-c4518e82c86f";
            var existingEmployee = _employeeService.GetById(johnLennonEmployeeId);

            var employee = new Employee
            {
                EmployeeId = "b7839309-3348-463b-a7e3-5de1c168beb3",
                FirstName = "Paul",
                LastName = "McCartney",
                Position = "Developer I",
                Department = "Engineering",
                DirectReports = new List<Employee>()
                {
                    existingEmployee
                }
            };

            // Act
            var newEmployee = _employeeService.Create(employee);

            // Assert
            Assert.AreEqual(null, newEmployee);
        }

        [TestMethod]
        [DataRow(null)]
        public void CreateEmployee_InvalidInput_ShouldFail(Employee employee)
        {
            // Act
            var newEmployee = _employeeService.Create(employee);

            // Assert
            Assert.AreEqual(null, newEmployee);
        }

        [TestMethod]
        public void UpdateEmployee_CreatesCircularRefernce_ShouldFail()
        {
            // Arrange
            var johnLennonEmployeeId = "16a596ae-edd3-4847-99fe-c4518e82c86f";
            var johnLennon = _employeeService.GetById(johnLennonEmployeeId);

            var paulMccartneyId = "b7839309-3348-463b-a7e3-5de1c168beb3";
            var paulMccartney = _employeeService.GetById(paulMccartneyId);

            var paulMccartneyOriginal = paulMccartney;
            var newDirectReports = new List<Employee>();
            newDirectReports.Add(johnLennon);
            paulMccartney.DirectReports = newDirectReports;
//                (johnLennon);

            // Act
            var newEmployee = _employeeService.Replace(paulMccartneyOriginal, paulMccartney);

            // Assert
            Assert.AreEqual(null, newEmployee);
        }

        [TestMethod]
        public void UpdateEmployee_NotCircularRefernce_ShouldPass()
        {
            // Arrange
            var peteBestId = "62c1084e-6e34-4630-93fd-9153afb65309";
            var peteBest = _employeeService.GetById(peteBestId);

            var paulMccartneyId = "b7839309-3348-463b-a7e3-5de1c168beb3";
            var paulMccartney = _employeeService.GetById(paulMccartneyId);

            var paulMccartneyOriginal = paulMccartney;
            var newDirectReports = new List<Employee>();
            newDirectReports.Add(peteBest);
            paulMccartney.DirectReports = newDirectReports;

            // Act
            var newEmployee = _employeeService.Replace(paulMccartneyOriginal, paulMccartney);

            // Assert
            Assert.AreEqual(paulMccartney, newEmployee);
        }

        [TestMethod]
        public void UpdateEmployee_NotSameEmployee_ShouldFail()
        {
            // Arrange
            var peteBestId = "62c1084e-6e34-4630-93fd-9153afb65309";
            var peteBest = _employeeService.GetById(peteBestId);

            var paulMccartneyId = "b7839309-3348-463b-a7e3-5de1c168beb3";
            var paulMccartney = _employeeService.GetById(paulMccartneyId);

            // Act
            var newEmployee = _employeeService.Replace(peteBest, paulMccartney);

            // Assert
            Assert.AreEqual(null, newEmployee);
        }

        [TestMethod]
        public void CreateEmployee_ReportsToThemself_ShouldFail()
        {
            // Arrange
            var literallyTheSameGuy = new Employee
            {
                EmployeeId = "newEmployee"
            };

            var employee = new Employee
            {
                EmployeeId = "newEmployee",
                FirstName = "Jo",
                LastName = "Shmo",
                Position = "Developer I",
                Department = "Engineering",
                DirectReports = new List<Employee>()
                {
                    literallyTheSameGuy
                }
            };

            // Act
            var newEmployee = _employeeService.Create(employee);

            // Assert
            Assert.AreEqual(null, newEmployee);
        }

    }
}
