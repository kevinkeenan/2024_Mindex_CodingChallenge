
using System;
using CodeChallenge.Data;
using CodeChallenge.Models;
using CodeChallenge.Repositories;
using CodeChallenge.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CodeCodeChallenge.Tests.Integration
{
    [TestClass]
    public class CompensationServiceTests
    {
        private static EmployeeContext _context;
        private static ICompensationService _compensationService;
        private static ICompensationRepository _compensationRepository;
        private static IServiceProvider _serviceProvider;
        private static ILogger<CompensationService> _logger;

        private static IEmployeeService _employeeService;
        private static IEmployeeRepository _employeeRepository;
        private static ILogger<EmployeeService> _empLogger;


        [ClassInitialize]
        public static void InitializeClass(TestContext context)
        {
            var options = new DbContextOptionsBuilder<EmployeeContext>()
                .UseInMemoryDatabase(databaseName: "EmployeeDB")
                .Options;

            _context = new EmployeeContext(options);
            SeedTestData(_context);

            var services = new ServiceCollection();
            services.AddTransient<ICompensationRepository, CompensationRepository>();
            services.AddTransient<ICompensationService, CompensationService>();
            services.AddLogging(builder => builder.AddConsole());

            services.AddTransient<IEmployeeRepository, EmployeeRepository>();
            services.AddTransient<IEmployeeService, EmployeeService>();
            _serviceProvider = services.BuildServiceProvider();
            _empLogger = _serviceProvider.GetRequiredService<ILogger<EmployeeService>>();
            _employeeRepository = new EmployeeRepository(null, _context);
            _employeeService = new EmployeeService(_empLogger, _employeeRepository);

            _logger = _serviceProvider.GetRequiredService<ILogger<CompensationService>>();
            _compensationRepository = new CompensationRepository(null, _context);
            _compensationService = new CompensationService(_logger, _compensationRepository);
        }

        [ClassCleanup]
        public static void CleanUpTest()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
        }

        private async static void SeedTestData(EmployeeContext context)
        {
            // Your seeding logic here
            var dataSeeder = new EmployeeDataSeeder(context);
            await dataSeeder.Seed();
            //await dataSeeder.CompensationSeed();
        }

        [TestMethod]
        [DataRow("16a596ae-edd3-4847-99fe-c4518e82c86f")]
        public void CreateCompensation_ForExistingEmployee_ShouldSucceed(string employeeId)
        {
            // Arrange
            var existingEmployee = _employeeService.GetById(employeeId);

            var compensation = new Compensation 
            { 
                Id = 1000 ,
                Salary = 1000000,
                EffectiveDate = DateTime.Now,
                Employee = existingEmployee,
                EmployeeId = employeeId
            };

            // Act
            var newCompensation = _compensationService.Create(compensation);

            // Assert
            Assert.AreEqual(compensation, newCompensation);
        }

        [TestMethod]
        [DataRow("invalid-id")]
        public void CreateCompensation_InvalidEmployee_ShouldFail(string employeeId)
        {
            // Arrange
            var invalidEmployee = new Employee
            {
                EmployeeId = employeeId,
                FirstName = "Test",
                LastName = "Test",
                Position = "Engineer",
                Department = "Engineering"
            };

            var compensation = new Compensation
            {
                Id = 99,
                Salary = 1000000,
                EffectiveDate = DateTime.Now,
                Employee = invalidEmployee
            };

            // Act
            var newCompensation = _compensationService.Create(compensation);

            // Assert
            Assert.AreEqual(null, newCompensation);
        }


        [TestMethod]
        [DataRow(-1)]
        [DataRow(0)]
        public void CreateCompensation_InvalidSalary_ShouldFail(double salary)
        {
            // Arrange
            var employeeId = "16a596ae-edd3-4847-99fe-c4518e82c86f";
            var existingEmployee = _employeeService.GetById(employeeId);

            var compensation = new Compensation
            {
                Id = 100,
                Salary = salary,
                EffectiveDate = DateTime.Now,
                Employee = existingEmployee
            };

            // Act
            var newCompensation = _compensationService.Create(compensation);

            // Assert
            Assert.AreEqual(null, newCompensation);
        }

        /// <summary>
        /// Passes when run inidivisually but not as part of whole, Wouldve worked had i seeded the compensation file in properly. 
        /// </summary>
        //[TestMethod]
        //public void GetCompensation_ByEmployeeId_ShouldSucceed()
        //{
        //    // Arrange
        //    var employeeId = "03aa1462-ffa9-4978-901b-7c001562cf6f";
        //    CreateCompensation_ForExistingEmployee_ShouldSucceed(employeeId);
        //    var expectedSalary = 1000000;

        //    // Act
        //    var compensation = _compensationService.GetById(employeeId);

        //    // Assert
        //    Assert.AreEqual(compensation.Salary, expectedSalary);
        //}

    }
}
